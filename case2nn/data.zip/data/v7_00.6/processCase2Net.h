#ifndef processCase2Net_H_INCL
#define processCase2Net_H_INCL

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declaration for neural net structure */
struct SNnNet;

/* Pointer to neural net structure */
typedef struct SNnNet* NN_PNET;

/**
 * The processCase2Net function processes a neural net which was converted from the
 * GKSS-FFBP format to the NNF format used by the MERIS level 2 processor.
 * <p>
 * The original FFBP net was trained with input vectors having the following definition: * <p>
 *     1: sun_thet in [1.8, 82.3] <br>
 *     2: thetav in [0.05245, 45] <br>
 *     3: phi in [0, 180] <br>
 *     4: log(rlw(412.3)) in [-9.959, -1.43766] <br>
 *     5: log(rlw(442.3)) in [-10.03, -1.43041] <br>
 *     6: log(rlw(489.7)) in [-9.97, -1.47394] <br>
 *     7: log(rlw(509.6)) in [-9.934, -1.58453] <br>
 *     8: log(rlw(559.5)) in [-9.792, -1.72206] <br>
 *     9: log(rlw(619.4)) in [-9.912, -2.22509] <br>
 *    10: log(rlw(664.3)) in [-10.2, -2.43411] <br>
 *    11: log(rlw(708.1)) in [-10.41, -2.79084] <br>
 * <p>
 * The original FFBP net was trained with output vectors having the following definition:
 * <p>
 *     1: log(conc_bpart) in [-5.364, 3.807] <br>
 *     2: log(conc_apig) in [-9.21, 0.4048] <br>
 *     3: log(conc_agelb+conc_apart) in [-5.293, 1.925] <br>
 * <p>
 * The ranges are used to normalize the in- and output vectors to values
 * in the range [0, 1].
 * This normalisation must be part of the neural net
 * given by <code>pNet</code> and is not performed within the processCase2Net
 * function.
 * 
 * @param pNet the neural net
 * @param pdInp input vector, points to an array of at least 11 double values
 * @param pdOut output vector, points to an array of at least 4 double values
 *              the last element contains the out-of-scope flag
 *              having either the value 0.0 or 1.0
 */
void processCase2Net(NN_PNET pNet, const double* pdInp, double* pdOut);

#ifdef __cplusplus
}
#endif

#endif /* processCase2Net_H_INCL */
