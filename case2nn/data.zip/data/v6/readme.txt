Lieber Herr Fomferra,

wie besprochen: alles wie sonst, nur die Berechnung 
'Summe der Abweichungsquadrate' noch anpassen.

o9_15x20_122.0.bunet ist das Vorwaerts-Netz
o9_52x20x5_1037.1.bunet ist das Inverse Netz

Eingabedaten: 4fomferra.inp 

bei cut (Summe der Abweichungsquadrate < .2): 4fomferra.res1
In 4fomferra.res2 steht als 4. Spalte 'Summe der Abweichungsquadrate'

MfG
H. Schiller



-- 
Dr. H. Schiller                        http://w3g.gkss.de/staff/schiller
GKSS Research Center                   Tel. 04152-87-1592
Max-Planck-Str.                        Fax  04152-87-1596
D- 21502 Geesthacht                    email: schiller@gkss.de