clear all
close('all')

invres=load('toplot.resinv');
npt=500;
invnnin=[invres(1:npt,1:10) rand(npt,1)];
save('4fomferra.inp', 'invnnin', '-ascii');

invnn=nnhs('52x20x5_1037.1.bunet');
forwnn=nnhs('15x20_122.0.net');

invnnres=zeros(npt,3);
forwnnin=zeros(1,6);
flag=zeros(npt,1);
dsq=zeros(npt,1);
dsqcut=0.2;

for n=1:npt
    invnnres(n,:)=ff_nnhs(invnn, invnnin(n,:));
    forwnnin=[invnnin(n,1:3) invnnres(n,:)];
    forwnnres=ff_nnhs(forwnn, forwnnin);
    sq=0.;
    for k=1:7
        sq=sq+(invnnin(n,3+k)-forwnnres(k))^2;       
    end
    dsq(n)=sq;
    if sq > dsqcut
        flag(n)=1;
    end
end

res1=[invnnres dsq];
res2=[invnnres flag];
save('4fomferra.res1', 'res1', '-ascii');
save('4fomferra.res2', 'res2', '-ascii');

